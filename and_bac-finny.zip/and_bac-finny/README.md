# rockonnect
NCI final project: Higher Diploma in Science and Web technologies
Author: Andrea Baccolini
Student number: 18147518
email: x18147518@student.ncirl.ie

final web app project: rockonnect web application
